<?php 
/**
 * 
 */
class Crud extends CI_Controller
{
	function __construct(){
		parent::__construct();		
		$this->load->model('m_motor');
		$this->load->helper('url');

	}

	function tambah_booking(){
		$nama = $this->input->post('nama');
		$email = $this->input->post('email');
		$no_hp = $this->input->post('no_hp');
		$tanggal = $this->input->post('tanggal');
		$jenis_motor = $this->input->post('jenis_motor');
		$jumlah = $this->input->post('jumlah');
		$message = $this->input->post('message');

		$data = array(
			'nama' => $nama,
			'email' => $email,
			'no_hp' => $no_hp,
			'tanggal' => $tanggal,
			'jenis_motor' => $jenis_motor,
			'jumlah' => $jumlah,
			'message' => $message
			);
		$this->m_motor->input_data($data,'booking_form');
		$this->session->set_flashdata('success', 'Transaksi Berhasil !');
		redirect('home/beranda');
	}

}