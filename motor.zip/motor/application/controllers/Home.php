<?php 
/**
 * 
 */
class Home extends CI_Controller
{
		function beranda(){
			$this->load->view('index');
		}
		function index(){
			$this->load->view('login');
		}
		
		function sewa(){
			$this->load->view('sewa');
		}


}