<?php 
/**
 * 
 */
class tgp extends CI_Controller
{
	function __construct(){
		parent::__construct();		
		$this->load->model('m_tanggapan');
		$this->load->helper('url');

	}

	function tanggapan(){
		$nama = $this->input->post('nama');
		$email = $this->input->post('email');
		$pesan = $this->input->post('pesan');

		$data = array(
			'nama' => $nama,
			'email' => $email,
			'pesan' => $pesan,
			
			);
		$this->m_tanggapan->input_data($data,'tanggapan');
		$this->session->set_flashdata('success', 'Tanggapan terkirim !');
		redirect('home/beranda');
	}

}