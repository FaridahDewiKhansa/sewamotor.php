<?php 
/**
 * 
 */
class M_motor extends CI_model
{
	
	function cek_login($table,$where){
        return $this->db->get_where($table,$where);
    }
    function tampil_data(){
    	return $this->db->get('booking_form');
    }

    function input_data($data,$table){
		$this->db->insert($table,$data);
	}

    function hapus_data($data,$no){
    	$this->db->where('no', $no);
    	$this->db->delete('booking_form');
    	$this->session->set_flashdata('sukses', "Data Berhasil Dihapus");
    }

    function edit_data($where, $table){
    	return $this->db->get_where($table,$where);
    }

    function update_data($where, $table){
    	return $this->db->get_where($table,$where);
	}
}