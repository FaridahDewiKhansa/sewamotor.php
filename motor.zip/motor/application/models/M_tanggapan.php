<?php 
/**
 * 
 */
class M_tanggapan extends CI_model
{
	
	function cek_login($table,$where){
        return $this->db->get_where($table,$where);
    }
    function tampil_data(){
    	return $this->db->get('tanggapan');
    }

    function input_data($data,$table){
		$this->db->insert($table,$data);
	}
}