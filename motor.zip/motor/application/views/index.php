<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <style type="text/css">
        /* Full-width input fields */
        input[type=text] {
          width: 85%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          box-sizing: border-box;
        }
        input[type=password] {
          width: 85%;
          padding: 12px 20px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          box-sizing: border-box;
        }

        /* Set a style for all buttons */
/*        button {
          background-color: #4CAF50;
          color: white;
          padding: 14px 20px;
          margin: 8px 0;
          border: none;
          cursor: pointer;
        }*/

        button:hover {
          opacity: 0.8;
        }

        /* Extra styles for the cancel button */
        .cancelbtn {
          width: auto;
          padding: 10px 18px;
          background-color: #f44336;
        }

        /* Center the image and position the close button */
        .imgcontainer {
          text-align: center;
          margin: 24px 0 12px 0;
          position: relative;
        }

        img.avatar {
          width: 40%;
          border-radius: 50%;
        }

        .container {
          padding: 16px;
        }

        span.psw {
          float: right;
          padding-top: 16px;
        }

        /* The Modal (background) */
        .modal {
          display: none; /* Hidden by default */
          position: fixed; /* Stay in place */
          z-index: 1; /* Sit on top */
          left: 0;
          top: 0;
          width: 100%; /* Full width */
          height: 100%; /* Full height */
          overflow: auto; /* Enable scroll if needed */
          background-color: rgb(0,0,0); /* Fallback color */
          background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
          padding-top: 60px;
        }

        /* Modal Content/Box */
        .modal-content {
          background-color: #fefefe;
          margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
          border: 1px solid #888;
          width: 80%; /* Could be more or less, depending on screen size */
        }

        /* The Close Button (x) */
        .close {
          position: absolute;
          right: 25px;
          top: 0;
          color: #000;
          font-size: 35px;
          font-weight: bold;
        }

        .close:hover,
        .close:focus {
          color: red;
          cursor: pointer;
        }

        /* Add Zoom Animation */
        .animate {
          -webkit-animation: animatezoom 0.6s;
          animation: animatezoom 0.6s
        }

        @-webkit-keyframes animatezoom {
          from {-webkit-transform: scale(0)} 
          to {-webkit-transform: scale(1)}
        }
          
        @keyframes animatezoom {
          from {transform: scale(0)} 
          to {transform: scale(1)}
        }

        /* Change styles for span and cancel button on extra small screens */
        @media screen and (max-width: 300px) {
          span.psw {
             display: block;
             float: none;
          }
          .cancelbtn {
             width: 100%;
          }
        }
        </style>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <!-- Custom Fonts -->
        <link rel="stylesheet" href="<?php echo base_url()?>assets/custom-font/fonts.css" />
        <!-- Bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css" />
        <!-- Font Awesome -->
        <link rel="stylesheet" href="<?php echo base_url()?>assets/css/font-awesome.min.css" />
        <!-- Bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootsnav.css">
        <!-- Fancybox -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/jquery.fancybox.css?v=2.1.5" media="screen" />	
        <!-- Custom stylesheet -->
        <link rel="stylesheet" href="<?php echo base_url()?>assets/css/custom.css" />
        <!--[if lt IE 9]>
                <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
    </head>
    <body>

        <!-- Header -->
        
            <?php 
              if ($this->session->flashdata('success')) {
                echo htmlspecialchars('<h2>Sukses !</h2>');
              }
            ?>
        <header>
            <!-- Top Navbar -->
            <div class="top_nav">
                <div class="container">
                    <ul class="list-inline info">
                        <li><a href="#"><span class="fa fa-phone"></span> 0852 222 111 421</a></li>
                        <li><a href="#"><span class="fa fa-envelope"></span> gratiasewamotor@gmail.com</a></li>
                        <li><a href="#"><span class="fa fa-clock-o"></span> Mon - Sat 9:00 - 19:00</a></li>
                    </ul>
                    <ul class="list-inline social_icon">
                        <li><a href=""><span class="fa fa-facebook"></span></a></li>
                        <li><a href=""><span class="fa fa-twitter"></span></a></li>
                        <li><a href=""><span class="fa fa-behance"></span></a></li>
                        <li><a href=""><span class="fa fa-dribbble"></span></a></li>
                        <li><a href=""><span class="fa fa-linkedin"></span></a></li>
                        <li><a href=""><span class="fa fa-youtube"></span></a></li>
                    </ul>			
                </div>
            </div><!-- Top Navbar end -->

            <!-- Navbar -->
            <nav class="navbar bootsnav">
                <!-- Top Search -->
                <div class="top-search">
                    <div class="container">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-search"></i></span>
                            <input type="text" class="form-control" placeholder="Search">
                            <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
                        </div>
                    </div>
                </div>

                <div class="container">
                    <!-- Atribute Navigation -->
                    <div class="attr-nav">
                        <ul>
                            <li class="search"><a href="#"><i class="fa fa-search"></i></a></li>
                        </ul>
                    </div>
                    <!-- Header Navigation -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                            <i class="fa fa-bars"></i>
                        </button>
                        <a class="navbar-brand" href=""><img class="logo" src="<?php echo base_url()?>assets/images/logo.png"
                        height= "70px" width= "40px" alt=""></a>
                        <span style="float: right; padding-top: 40px; color: white;">G R A T I A</span>
                    </div>

                    <!-- Navigation -->
                    <div class="collapse navbar-collapse" id="navbar-menu">
                        <ul class="nav navbar-nav menu">
                            <li><a href=>Home </a></li>                    
                            <li><a href="#about">About Us</a></li>
                            <li><a href="#bookingForm">Booking Form</a></li>
                            <li><a href="#contact_form">Contact Us</a></li>
                            <li><a  onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Login</a></li>
                            <div id="id01" class="modal">
  
    <form class="modal-content animate" action="login/aksilogin" method="post">
        <div class="imgcontainer">
          <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
          <img src="img_avatar2.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="uname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="username" required>
      <br>
      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password" required>
      <br>
      <button href="Home/beranda" type="submit" class="btn btn-primary" >Login</button>
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="btn btn-danger">Cancel</button>
      <br>
    </div>
  </form>
</div>

                        </ul>
                    </div>
                </div>   
            </nav><!-- Navbar end -->
        </header><!-- Header end -->


        <section id="home" class="home">
            <!-- Carousel -->
            <div id="carousel" class="carousel slide" data-ride="carousel">
                <!-- Carousel-inner -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <img src="<?php echo base_url()?>assets/images/sewamotor.jpg" alt="Construction">
                        <div class="overlay">
                            <div class="carousel-caption">
                                <h3>Gratia Sewa Motor</h3>
                                <h1>Jasa Penyewaan Motor</h1>
                                <h1 class="second_heading">Murah dan Terpercaya</h1>
                                <p>Jasa penyewaan motor khusus daerah Bali</p>
                            </div>					
                        </div>
                    </div>
                    <div class="item">
                        <img src="<?php echo base_url()?>assets/images/sewamotor2.jpg" alt="Construction">
                        <div class="overlay">
                            <div class="carousel-caption">
                                <h3>Gratia Sewa Motor</h3>
                                <h1>Jasa Penyewaan Motor</h1>
                                <h1 class="second_heading">Murah dan Terpercaya</h1>
                                <p>Jasa penyewaan motor khusus daerah Bali</p>
                            </div>					
                        </div>
                    </div>
                    <div class="item">
                        <img src="<?php echo base_url()?>assets/images/sewamotor3.jpg" alt="Construction">
                        <div class="overlay">
                            <div class="carousel-caption">
                                <h3>Gratia Sewa Motor</h3>
                                <h1>Jasa Penyewaan Motor</h1>
                                <h1 class="second_heading">Murah dan Terpercaya</h1>
                                <p>Jasa penyewaan motor khusus daerah Bali</p>
                            </div>					
                        </div>
                    </div>
                </div><!-- Carousel-inner end -->



                <!-- Controls -->
                <a class="left carousel-control" href="#carousel" role="button" data-slide="prev">
                    <span class="fa fa-angle-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#carousel" role="button" data-slide="next">
                    <span class="fa fa-angle-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div><!-- Carousel end-->

        </section>


        <!-- About -->
        <section id="about">
            <div class="container about_bg">
                <div class="row">
                    <div class="col-lg-7 col-md-6">
                        <div class="about_content">
                            <h2>Gratia Group</h2>
                            <h3>Gratia Sewa Motor</h3>
                            <p>Berdiri sejak 1920 oleh Gratia Group</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-lg-offset-1">
                        <div class="about_banner">
                            <img src="<?php echo base_url()?>assets/images/sewa.png" style="height: 400px;  width: 600px; padding-right: 200px;"  alt="Construction"> 
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- About end -->

<!-- Portfolio -->
        <section id="portfolio">
            <div class="container portfolio_area text-center">
                <h2>Yuk tunggu apalagi?</h2>
                <p>Ingin jalan-jalan di Bali? Sewa motor di Gratia Sewa Motor sekarang!!</p>

                <div id="filters">
                    <button class="button" data-filter=".interior">Matic</button>
                    <button class="button" data-filter=".isolation">Vespa</button>
                    <button class="button" data-filter=".plumbing">Sport</button>
                </div>
                <!-- Portfolio grid -->   
                    <div class="col-md-3 col-sm-6">
                        <div class="khansa">
                            <img src="<?php echo base_url()?>assets/images/khansa.png"/>
                        </div>
                    </div>

                     <div class="col-md-3 col-sm-6">
                        <div class="yasmin">
                            <img src="<?php echo base_url()?>assets/images/yasmin.png"/>
                        </div>
                    </div>

                     <div class="col-md-3 col-sm-6">
                        <div class="khansa">
                            <img src="<?php echo base_url()?>assets/images/matic.png"/>
                        </div>
                    </div>

                     <div class="col-md-3 col-sm-6">
                        <div class="khansa">
                            <img src="<?php echo base_url()?>assets/images/riyadi.png"/>
                        </div>
                    </div>


                    </div><!-- Portfolio grid end -->
            </div>
        </section>
        <!-- Portfolio end -->

        <!-- Why us -->
        <section id="why_us">
            <div class="container text-center">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="head_title">
                            <h2>KENAPA HARUS GRATIA?</h2>
                            <p>Gratia hadir sebagai sahabat travelling-mu di Indonesia</p>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="why_us_item">
                            <img src="<?php echo base_url()?>assets/images/quali.jpg"
                            style="height: 150px;  width: 250px; alt="Our Services" />
                            <h4>Quality</h4>
                            <p>Selalu Berkualitas.</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="why_us_item">
                           <img src="<?php echo base_url()?>assets/images/time.jpg"
                           style="height: 150px;  width: 250px;
                           alt="Our Services" />
                            <h4>Cekatan</h4>
                            <p>Cekatan dalam pekerjaan untuk mengefisiensikan waktu dan tenaga.</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="why_us_item">
                            <img src="<?php echo base_url()?>assets/images/ramah.jpg"
                            style="height: 150px;  width: 250px; alt="Our Services" />
                            <h4>Ramah</h4>
                            <p>Selalu menunjung tinggi keramahan.Karena client adalah raja.</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="why_us_item">
                            <img src="<?php echo base_url()?>assets/images/profesional.jpg"style="height: 150px;  width: 250px; alt="Our Services" />
                            <h4>Professional Services</h4>
                            <p>Profesional dalam kondisi apapun dan selalu terpercaya.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- Why us end -->

        <div class="content"><div class="ic"></div>
        <div class="container_12">
          <div class="grid_5">
             <div class="top_nav">
                <div class="container">
            <h3>Booking Form</h3>
            <form id="bookingForm" action="<?php echo base_url(). 'crud/tambah_booking'; ?>" method="POST">
              <div class="fl1">
                <div class="tmInput">
                  <input name="nama" placeHolder="Name:" type="text" data-constraints='@NotEmpty @Required @AlphaSpecial'>
                </div>
              </div>
              <div class="fl1">
                <div class="tmInput">
                  <input name="email" placeHolder="Email:" type="text" data-constraints="@NotEmpty @Required @Email">
                </div>
                <div class="tmInput mr0">
                  <input name="no_hp" placeHolder="No.HP:" type="text" data-constraints="@NotEmpty @Required">
                </div>
              </div>
              <div class="clear"></div>
              <div class="clear"></div>
              <strong>Date</strong>
              <label class="tmDatepicker">
                <input type="text" name="tanggal"  placeHolder='DD/MM/YY' type="text"data-constraints="@NotEmpty @Required @Date">
              </label>
              <div class="clear"></div>
              <div class="tmRadio">
                <p>Jenis Motor</p>
                <input name="jenis_motor" value="1" type="radio" id="tmRadio0" data-constraints='@RadioGroupChecked(name="Comfort", groups=[RadioGroup])' checked/>
                <span>Matic</span>
                <input name="jenis_motor" value="2" type="radio" id="tmRadio1" data-constraints='@RadioGroupChecked(name="Comfort", groups=[RadioGroup])' />
                <span>Vespa</span>
                <input name="jenis_motor" value="3" type="radio" id="tmRadio2" data-constraints='@RadioGroupChecked(name="Comfort", groups=[RadioGroup])' />
                <span>Sport</span>
              </div>
              <div class="clear"></div>
              <div class="fl1 fl2">
                <em>Jumlah</em>
                <select name="jumlah" class="tmSelect auto" data-class="tmSelect tmSelect2" data-constraints="">
                  <option>1</option>
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                </select>
                <div class="clear height1"></div>
              </div>
              <div class="clear"></div>
              <div class="tmTextarea">
                <textarea name="message" placeHolder="Message" data-constraints='@NotEmpty @Required @Length(min=20,max=999999)'></textarea>
              </div>
              <button href="Home/beranda" type="submit">Submit</button>
            </form>
          </div>
          <div class="clear"></div>
        </div>
      </div>
    </div>

        

        <!-- Testimonial -->
        <section id="testimonial">
            <div class="container text-center testimonial_area">
                <h2>Founder Gratia Group</h2>
                <p>Para pendiri Gratia Group</p>

                <div class="row">
                    <div class="col-md-4">
                        <div class="testimonial_item">
                            <div class="testimonial_content text-left">
                                <p>Mau jalan-jalan di Bali? Percayakan pada Gratia Group</p>
                            </div>
                            <img src="<?php echo base_url()?>assets/images/yasmin.png" alt="Testimonial" />
                            <p class="worker_name">Aulia Yasmin</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="testimonial_item">
                            <div class="testimonial_content">
                                <p>Gratia selalu hadir di setiap perjalanan-mu!</p>
                            </div>
                            <img src="<?php echo base_url()?>assets/images/khansa.png" alt="Testimonial" />
                            <p class="worker_name">Faridah Dewi Khansa</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="testimonial_item">
                            <div class="testimonial_content">
                                <p>Gratia Group Selalu Di Hati</p>
                            </div>
                            <img src="<?php echo base_url()?>assets/images/riyadi.png" alt="Testimonial" />
                            <p class="worker_name">Riyadi Fauzi</p>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- Testimonial end -->

        <!-- Contact form -->
        
    
<div class="content"><div class="ic"></div>
        <div class="container_12">
          <div class="grid_5">
            <section id="contact_form">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h2>Kritik dan Saran?</h2>
                        <h2 class="second_heading">Sampaikan saja disini!</h2>
                    </div>
              <form id="bookingForm" action="<?php echo base_url(). 'tgp/tanggapan'; ?>" method="POST">
              <div class="fl1">
                <div class="tmInput">
                  <input name="nama" placeHolder="Nama:" type="text" data-constraints='@NotEmpty @Required @AlphaSpecial'>
                </div>
              </div>
              <div class="fl1">
                <div class="tmInput">
                  <input name="email" placeHolder="Email:" type="text" data-constraints="@NotEmpty @Required @Email">
                </div>
                <div class="tmInput mr0">
                  <input name="pesan" placeHolder="Pesan:" type="text" data-constraints="@NotEmpty @Required">
                </div>
              </div>
              <button href="Home/beranda" type="submit">Submit</button>
            </form>
          </div>
          <div class="clear"></div>
        </div>
      </div>
    </div>
        </section><!-- Contact form end -->

        <!-- Footer -->
        <footer>
            <!-- Footer top -->
            <div class="container footer_top">
                <div class="row">
                    <div class="col-lg-4 col-sm-7">
                        <div class="footer_item">
                            <h4>Gratia Group</h4>
                            <p>Gratia.co</p>
                            <p>Gratia Sewa Motor</p>
                            <p>Gratia Sewa Mobil</p>
                            <p>Gratia Travel</p>

                            
                        </div>
                    </div>
                    <div class="col-lg-2 col-sm-5">
                        <div class="footer_item">
                            <h4>Cabang Gratia</h4>
                            <ul class="list-unstyled footer_menu">
                                <li><a href=""><span class="fa fa-play"></span> Bandung</a>
                                <li><a href=""><span class="fa fa-play"></span> Bali</a>
                                <li><a href=""><span class="fa fa-play"></span> Jakarta</a>
                                <li><a href=""><span class="fa fa-play"></span> Medan</a>
                                <li><a href=""><span class="fa fa-play"></span> Jogjakarta</a>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-5">
                        <div class="footer_item">
                            <h4>Contact us</h4>
                            <ul class="list-unstyled footer_contact">
                                <li><a href=""><span class="fa fa-map-marker"></span> Cibiru, Bandung</a></li>
                                <li><a href=""><span class="fa fa-envelope"></span> gratiasewamotor@gmail.com</a></li>
                                <li><a href=""><span class="fa fa-mobile"></span><p>0852 222 111 421 <br />0853 1460 4737</p></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div><!-- Footer top end -->

            <!-- Footer bottom -->
           

        <!-- JavaScript -->
        <script src="<?php echo base_url()?>assets/js/jquery-1.12.1.min.js"></script>
        <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>

        <!-- Bootsnav js -->
        <script src="<?php echo base_url()?>assets/js/bootsnav.js"></script>

        <!-- JS Implementing Plugins -->
        <script src="<?php echo base_url()?>assets/js/isotope.js"></script>
        <script src="<?php echo base_url()?>assets/js/isotope-active.js"></script>
        <script src="<?php echo base_url()?>assets/js/jquery.fancybox.js?v=2.1.5"></script>

        <script src="<?php echo base_url()?>assets/js/jquery.scrollUp.min.js"></script>

        <script src="<?php echo base_url()?>assets/js/main.js"></script>
        <script>
        // Get the modal
        var modal = document.getElementById('id01');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
        </script>
    </body>	
</html>	